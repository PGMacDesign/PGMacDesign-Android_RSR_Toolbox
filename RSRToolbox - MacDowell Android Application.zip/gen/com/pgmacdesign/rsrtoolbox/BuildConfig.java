/** Automatically generated file. DO NOT MODIFY */
package com.pgmacdesign.rsrtoolbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}